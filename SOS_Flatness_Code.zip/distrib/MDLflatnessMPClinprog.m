
function [t,n,act,LS,u,Phi,q1,q2]=MDLflatnessMPClinprog(x,qff,FTreserve,robotpars,musclepars,g,T,delta,tau_act,beta_act)
%Linear programming solution for use in a receding-horizon implementation

%Uses the linear programming solution on the basis of :
%Matching only joint positions and velocities at the start of each
%optimization

%Terminal conditions are limited to target setpoint and zero velocity. This
%can be done with a cubic polynomial for q

%Zero jerk and zero rate of jerk can still be imposed for true terminal
%equilibrium without affecting the validity of the LP solution
%Since the optimal co-contractions are constant, the conditions
%Ydot(T)=Yddot(T)=0 are automatically assumed for true terminal eq. cases.

%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%



%Parse parameters

m1=robotpars.m1;
m2=robotpars.m2;
l1=robotpars.l1;
lc1=robotpars.lc1;
l2=robotpars.l2;
lc2=robotpars.lc2;
I1=robotpars.I1;
I2=robotpars.I2;

d1=musclepars.d1;
d2=musclepars.d2;
a0=musclepars.a0;
Ls=musclepars.Ls;
Lo=musclepars.Lo;
Vm=musclepars.Vm;
W=musclepars.W;
Fmax=musclepars.Fmax;
k=musclepars.k;
aPEE=musclepars.aPEE;

%Parse inputs

z=x(1:4);
z_1=z(1:2);
z_2=z(3:4);
LS=x(5:10);
a=x(11:end);

q0=z_1;
qdot0=z_2;

ArmMatrix=[d1';d2'];

D=[ArmMatrix;0.5 0.5 0 0 0 0;0 0 0.5 0.5 0 0;0 0 0 0 0.5 0.5;1 0 0 0 0 0];

%Solution by 3th-order polynomial: 
%Matching specified pos and vel at initial time. First derivative is zero
%at the final time

coeff1=optim3poly(q0(1),qdot0(1),qff(1),T);
coeff2=optim3poly(q0(2),qdot0(2),qff(2),T);

%Find the torque bounds for the above trajectories
    
[tau1,tau2,taumax1,taumin1,taumax2,taumin2,taumax12,taumin12]=calcTauBounds2linkEnum(T,robotpars,coeff1,coeff2,delta,g,0);

%Distribution matrix inverse
Di=inv(D);

Dy=Di(:,3:6);
Df=Di(:,1:2);

%LP solution

%Solve optimization for y3,y4,y5 and y6
leftside=Dy;
rightside=FTreserve-Df(:,1).*[0;0;taumin1;taumax1;taumin12;taumax12];

%Linear programming solution - under the constant y
%assumption

%The terminal eq. constraint has been worked in to reduce searchspace
%The integral (area) has been found symbolically

Y36=linprog([1 1 1 0],[-leftside;-eye(4)],[-rightside;zeros(4,1)]);

t=[0:delta:T];

y3=Y36(1);
y4=Y36(2);
y5=Y36(3);
y6=Y36(4);

%Evaluate motion and derivatives
q1=polyval(coeff1,t);
q2=polyval(coeff2,t);
coeffd1=polyder(coeff1);
coeffd2=polyder(coeff2);
q1dot=polyval(coeffd1,t);
q2dot=polyval(coeffd2,t);

%Calculate f1dot and f2dot by numerical differentiation
%(repeat last entry to maintain length

f1dot=diff([tau1 tau1(end)])/delta;
f2dot=diff([tau2 tau2(end)])/delta;

NT=length(t);

ydot=zeros(4,1);

for i=1:2 %this is post-optimization, so we don't predict through the whole horizon, for speed
    %this is possible because the previous optimization did not include
    %constraints for a, n.
    
    %find tendon forces
    Phi(:,i)=Di*[tau1(i);tau2(i);Y36];
    
    %find series element lengths
    LS(:,i)=SEEinv(Phi(:,i),Ls,k);
  
    %find LS rates 
    denom=SEEPrime(LS(:,i),Ls,k);
    num=Di*[f1dot(i);f2dot(i);ydot];
    LSdot(:,i)=num./denom;
    
    %find LC, u and a
    L(:,i)=a0-d1*q1(i)-d2*q2(i);
    Ldot(:,i)=-d1*q1dot(i)-d2*q2dot(i);
    LC(:,i)=L(:,i)-LS(:,i);
    u(:,i)=LSdot(:,i)-Ldot(:,i);
    FP(:,i)=PE(LC(:,i),aPEE,Lo);
    act(:,i)=(Phi(:,i)-FP(:,i))./(f1(LC(:,i),W,Lo,Fmax).*g1(u(:,i),Vm).*Fmax);
end

%Obtain activation derivatives using diff
%(repeat last entry to maintain length)

act=[act act(:,end)];

a1dot=diff(act(1,:))/delta;
a2dot=diff(act(2,:))/delta;

a3dot=diff(act(3,:))/delta;
a4dot=diff(act(4,:))/delta;

a5dot=diff(act(5,:))/delta;
a6dot=diff(act(6,:))/delta;


%Solve for neural inputs assuming a saturation function in the activation
%dynamics
for j=1:1
    [n,solfound]=solvesat(tau_act,beta_act,act(1,j),a1dot(j));
    n1(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(2,j),a2dot(j));
    n2(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(3,j),a3dot(j));
    n3(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(4,j),a4dot(j));
    n4(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(5,j),a5dot(j));
    n5(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(6,j),a6dot(j));
    n6(j)=n;
end

%Return optimal n short sequence and state predictions

t=t';
n=[n1' n2' n3' n4' n5' n6'];


end


function coeff=optim3poly(q0,qdot0,qf,T)

Ainv=[3/T^2,  -1/T;
-2/T^3, 1/T^2];

B=[qf-q0-qdot0*T;-qdot0];

c23=Ainv*B;

coeff=flipud([q0;qdot0;c23])';


end