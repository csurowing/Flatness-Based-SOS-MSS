%Inverse of tendon force function (outside slack)

function LSEE=SEEinv(FT,s,k)

LSEE=sqrt(FT./k)+s;
    
