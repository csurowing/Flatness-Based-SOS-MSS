%inverse of velocity dependence function


function out=ginv(z,Vm)

A = 0.25;			% Hill constant
gmax=1.5;           % Maximum ecc to isometric force ratio

% zNegLim = g(200*ones(length(z),1),Vm);
% zPosLim = g(-200*ones(length(z),1),Vm);

for idx = 1:length(z)
%     if z(idx) < zNegLim(idx)
%         x1 = zNegLim(idx);
%         y1 = 200;
%         
%         x2 = g(199,Vm(idx));
%         y2 = 199;
%         
%         out(idx) = (y2-y1)/(x2-x1)*(z(idx)-x1)+y1;
    if z(idx)<=1
        out(idx) =(Vm(idx)-z(idx).*Vm(idx))./(1+z(idx)/A); 			 % CE shortens (Hill model)
    else %z(idx) < zPosLim(idx)
        out(idx)=-(z(idx)-1)*(gmax-1)*A.*Vm(idx)./((A+1)*(gmax-z(idx))); % CE lengthens (Katz model)
%     else
%         x1 = zPosLim(idx);
%         y1 = -200;
%         
%         x2 = g(-199,Vm(idx));
%         y2 = -199;
%         
%         out(idx) = (y2-y1)/(x2-x1)*(z(idx)-x1)+y1;
    end
end

out = out';
