 
%Steady-state optimizer

%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%


%Given initial joint positions, the function returns LS and activations
%producing steady-state conditions, under minimization of co-contraction
%sums and out-of-slack constraints

function [a,LS,Phi]=FlatSSInit(q0,robotpars,musclepars,g,FTreserve)


% define time constant
tau_act0 = 0.01;  
beta_act = 0.25;
tau_deact = tau_act0/beta_act;


load aSEEandaPEE                           
                            
%Linkage constants

%Parse parameters

m1=robotpars.m1;
m2=robotpars.m2;
l1=robotpars.l1;
lc1=robotpars.lc1;
l2=robotpars.l2;
lc2=robotpars.lc2;
I1=robotpars.I1;
I2=robotpars.I2;

d1=musclepars.d1;
d2=musclepars.d2;
a0=musclepars.a0;
Ls=musclepars.Ls;
Lo=musclepars.Lo;
Vm=musclepars.Vm;
W=musclepars.W;
Fmax=musclepars.Fmax;
k=musclepars.k;
aPEE=musclepars.aPEE;

ArmMatrix=[d1';d2'];

D=[ArmMatrix;0.5 0.5 0 0 0 0;0 0 0.5 0.5 0 0;0 0 0 0 0.5 0.5;1 0 0 0 0 0];


%Calculate gravity torques
tau1=(m1*lc1+m2*l1)*g*cos(q0(1))+m2*lc2*g*cos(q0(1)+q0(2))
tau2=m2*lc2*g*cos(q0(1)+q0(2))

Di=inv(D);

Dy=Di(:,3:6);
Df=Di(:,1:2);

%Linear programming solution - under the constant y
%assumption

leftside=Dy;
rightside=FTreserve-Df*[tau1;tau2];

Y36=linprog([1 1 1 0],[-leftside;-eye(4)],[-rightside;zeros(4,1)]);

y3=Y36(1);
y4=Y36(2);
y5=Y36(3);
y6=Y36(4);

    
%find tendon forces that cancel the gravity torque with minimal
%co-contractions but guarantee the specified force reserves against slack

Phi=Di*[tau1;tau2;Y36];
    
%find series element lengths
LS=SEEinv(Phi,Ls,k);
  
%find LC, u and a
    L=a0-d1*q0(1)-d2*q0(2);
    LC=L-LS;
    FP=PE(LC,aPEE,Lo);
    a=(Phi-FP)./(f1(LC,W,Lo,Fmax).*Fmax);