%SOS_Flatness_OL

%Solves an optimal open-loop problem with initial condition matching and
%terminal equilibrium for the 2 dof, 6 muscle arm model.
%
%The resulting neural input histories are then applied to a forward dynamic
%simulation for verification. It takes a few minutes to run, because of
%tight tolerances required in ode45 for an open-loop input simulation.

%SOStools / SeDuMi must be installed

%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%

%Physical parameters taken from paper by Jagodnik

clear;clc;close all

% define time constant
tau_act = 0.01;  
beta_act = 0.25;
tau_deact = tau_act/beta_act;

%Load data on muscle function shapes
load aSEEandaPEE                           
                            
%Linkage constants

robotpars.m1=2.24;
robotpars.m2=1.76;
robotpars.l1=0.33;
robotpars.lc1=0.1439;  %to center of mass
robotpars.l2=0.32;
robotpars.lc2=0.2182;  %to center of mass
robotpars.I1=0.0253;
robotpars.I2=0.0395;


%Kinematic info on muscle attachment
d1=[0.05;-0.05;0.03;-0.03;0;0];
d2=[0;0;0.03;-0.03;-0.03;0.03];
a0=[0.1840;0.1055;0.4283;0.1916;0.2387;0.1681];
%Muscle slack parameters
Ls=[0.0538;0.0538;0.2298;0.1905;0.1905;0.0175];

%Optimal lengths
Lo = [0.1280 0.1280 0.1422 0.0877 0.0877 0.1028]';

Vm = 10*Lo;
W  = 0.56*ones(6,1);

%Max muscle forces
Fmax=[800;800;1000;1000;700;700];

%k vector
k=Fmax./(0.04*Ls).^2;

musclepars.d1=d1;
musclepars.d2=d2;
musclepars.a0=a0;
musclepars.Ls=Ls;
musclepars.Lo=Lo;
musclepars.Vm=Vm;
musclepars.W=W;
musclepars.Fmax=Fmax;
musclepars.k=k;
musclepars.aPEE=aPEE;
%musclepars.aSIGM=aSIGM;


%Setup initial conditions
q0=[0;10]*pi/180;qdot0=[0.001;0.002];
%a small initial velocity used to demonstrate that the optimal Y doesn't
%have to be a constant in the general case. If qdot=0, the optimal solution
%for Y is constant. It seems that when both boundary conditions are
%equilibrium, this happens. More study is necessary to conclude this in
%general

%Choose motion target
qf=[90;0]*pi/180;

%Choose prediction horizon and discretization interval
N=31;  
T=3;
delta=T/(N-1);

g=1*9.81; %Select gravity constant

FTreserve=10*ones(6,1);
%Feasible initial conditions for act and LS
%(contact authors for details on how to generate)
load OL_IC


z0=[q0;qdot0];
x0=[z0;LS0;act0];
x=x0;


%Call flatness - SOS optimizer
[t,n,act,LS,u,Phi,q1pred,q2pred]=SOSflatOPT(x,qf,FTreserve,robotpars,musclepars,g,T,delta,tau_act,beta_act); 


%Post-process to find co-contraction histories
E=[0.5 0.5 0 0 0 0;0 0 0.5 0.5 0 0;0 0 0 0 0.5 0.5;1 0 0 0 0 0];

Y36=E*Phi;

%Run forward integration using the optimal neural controls, for
%verification
n_time=t;
T=t(end);
z0=[q0;qdot0];
x0=[z0;LS0;act0];

% Set options
atol_ode  = 1e-6;
rtol_ode  = 1e-6;
options = odeset('AbsTol', atol_ode, 'RelTol', rtol_ode);
%Without these options, the integration may diverge
 
[TOUT,YOUT]=ode45(@(t,x) mdlStateDer(t,x,n_time,n,robotpars,musclepars,g,tau_act,beta_act),[0  T],x0,options);


%Prepare figures
figure(1)
subplot(2,1,1);
plot(t,q1pred,'+k');hold on
plot(TOUT,YOUT(:,1),'k','LineWidth',2)
legend('q (optimal planning)','q (forward integration)')
ylabel('$q_1$', 'Fontsize',14,'Interpreter','Latex')
title('Open-Loop Optimization: Planned and Actual Joint Trajectories','FontSize',14,'Interpreter','Latex')

subplot(2,1,2);
plot(t,q2pred,'+k');hold on
plot(TOUT,YOUT(:,2),'k','LineWidth',2)
ylabel('$q_2$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Time,s' ,'Fontsize',14,'Interpreter','Latex')


figure(2)
subplot(3,2,1)
plot(t,LS(1,:),'+k'); hold on
plot(TOUT,YOUT(:,5),'k')
legend('LS (optimal planning)','LS (forward integration)')
axis([0 3 0.0545 0.05466])
ylabel('$LS_1$', 'Fontsize',14,'Interpreter','Latex')
title('Open-Loop Optimization: SE Lengths','FontSize',14,'Interpreter','Latex')
subplot(3,2,2)
plot(t,LS(2,:),'+k'); hold on
plot(TOUT,YOUT(:,6),'k')
axis([0 3 0.054 0.05415])
ylabel('$LS_2$', 'Fontsize',14,'Interpreter','Latex')
subplot(3,2,3)
plot(t,LS(3,:),'+k'); hold on
plot(TOUT,YOUT(:,7),'k')
ylabel('$LS_3$', 'Fontsize',14,'Interpreter','Latex')
subplot(3,2,4)
plot(t,LS(4,:),'+k'); hold on
plot(TOUT,YOUT(:,8),'k')
ylabel('$LS_4$', 'Fontsize',14,'Interpreter','Latex')
subplot(3,2,5)
plot(t,LS(5,:),'+k'); hold on
plot(TOUT,YOUT(:,9),'k')
ylabel('$LS_5$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Time,s' ,'Fontsize',14,'Interpreter','Latex')
subplot(3,2,6)
plot(t,LS(6,:),'+k'); hold on
plot(TOUT,YOUT(:,10),'k')
ylabel('$LS_6$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Time,s' ,'Fontsize',14,'Interpreter','Latex')


figure(3)
subplot(3,2,1)
plot(t,act(1,1:end-1),'+k'); hold on
plot(TOUT,YOUT(:,11),'k','LineWidth',2)
plot(t,n(:,1),'--k')
ylabel('$n_1,a_1$', 'Fontsize',14,'Interpreter','Latex')
title('Open-Loop Optimization: Activations and Neural Inputs','FontSize',14,'Interpreter','Latex')
%Create inset for zoom in
% create smaller axes in top right, and plot on it
axes('Position',[.35 .69 0.1 0.2])
box on
plot(t(11:16),act(1,11:16),'+k'); hold on
plot(TOUT(5590:8565),YOUT(5590:8565,11),'k','LineWidth',2)
plot(t(11:16),n(11:16,1),'--k')
axis([1 1.2 0.16 0.2])

subplot(3,2,2)
plot(t,act(2,1:end-1),'+k'); hold on
plot(TOUT,YOUT(:,12),'k','LineWidth',2)
plot(t,n(:,2),'--k')
ylabel('$n_2,a_2$', 'Fontsize',14,'Interpreter','Latex')
legend('a (optimal planning)','a (forward integration)','n')
subplot(3,2,3)
plot(t,act(3,1:end-1),'+k'); hold on
plot(TOUT,YOUT(:,13),'k','LineWidth',2);
plot(t,n(:,3),'--k')
ylabel('$n_3,a_3$', 'Fontsize',14,'Interpreter','Latex')
subplot(3,2,4)
plot(t,act(4,1:end-1),'+k'); hold on
plot(TOUT,YOUT(:,14),'k','LineWidth',2)
plot(t,n(:,4),'--k')
ylabel('$n_4,a_4$', 'Fontsize',14,'Interpreter','Latex')
subplot(3,2,5)
plot(t,act(5,1:end-1),'+k'); hold on
plot(TOUT,YOUT(:,15),'k','LineWidth',2)
plot(t,n(:,5),'--k')
ylabel('$n_5,a_5$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Time,s' ,'Fontsize',14,'Interpreter','Latex')
subplot(3,2,6)
plot(t,act(6,1:end-1),'+k'); hold on
plot(TOUT,YOUT(:,16),'k','LineWidth',2)
plot(t,n(:,6),'--k')
ylabel('$n_6,a_6$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Time,s' ,'Fontsize',14,'Interpreter','Latex')

figure(4)
plot(t,Y36(1,:),'k-');hold on
plot(t,Y36(2,:),'k-+');
plot(t,Y36(3,:),'k-o');

legend('$y_3$','$y_4$','$y_5$')
ylabel('$y_3,y_4,y_5$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Time,s' ,'Fontsize',14,'Interpreter','Latex')
title('Open-Loop Optimization: Co-Contractions','FontSize',14,'Interpreter','Latex')


