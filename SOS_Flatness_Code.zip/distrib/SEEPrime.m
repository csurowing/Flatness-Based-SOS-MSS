%Returns tendon force derivative (quadratic model)

function out=SEEPrime(LSEE,s,k)

out=2*k.*(LSEE-s);



