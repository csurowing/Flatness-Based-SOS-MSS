%Function to find the coefficients of a 5th-order
%polynomial to fit the "toe" region of the normalized
%force-length curve for the SEE (tendon)

%Based on Zajac's paper

%sn is the nondimensional slack length
%Calculations assume certain key points
%in the stress-strain curve for tendon.

function [a,kn,aPrime,aPPrime]=fitSEEnorm(sn)

%Compute normalized stiffness for linear portion
kn=0.5/(1.033-1.02)/sn;

%A matrix
A=[sn^5 sn^4 sn^3 sn^2 sn 1;
   (1.02*sn)^5 (1.02*sn)^4 (1.02*sn)^3 (1.02*sn)^2 1.02*sn 1;
   5*sn^4 4*sn^3 3*sn^2 2*sn 1 0;
   20*sn^3 12*sn^2 6*sn 2 0 0;
   5*(1.02*sn)^4 4*(1.02*sn)^3 3*(1.02*sn)^2 2*(1.02*sn) 1 0;
   20*(1.02*sn)^3 12*(1.02*sn)^2 6*(1.02*sn) 2 0 0];

%b vector
b=[0;0.5;0;0;kn;0];

%Compute coefficients

a=pinv(A)*b;

aPrime = polyder(a);

aPPrime = polyder(aPrime);

%Plot overall curve

L=[0 sn:0.0005:1.02*sn 1.033*sn];
for i=1:length(L),
    if L(i)<sn,
        Fn(i)=0;
    elseif L(i)<1.02*sn,
        Fn(i)=polyval(a,L(i));
    else
        Fn(i)=0.5+kn*(L(i)-1.02*sn);
    end
end

%find boundary indices

idx=find(L==1.02*sn);
plot(L(1:2),Fn(1:2),'b');hold on
plot(L(3:idx),Fn(3:idx),'r');
plot(L(idx:end),Fn(idx:end),'k')
axis([0.95*sn 1.033*sn 0 1]);




