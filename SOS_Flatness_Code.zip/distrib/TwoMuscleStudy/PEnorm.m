%PEnorm.m

%Returns the normalized passive muscle force (PE)

function out=PEnorm(LCEn,aPE)

if LCEn<1,
        out=0;
    else
        out=polyval(aPE,LCEn);
end
