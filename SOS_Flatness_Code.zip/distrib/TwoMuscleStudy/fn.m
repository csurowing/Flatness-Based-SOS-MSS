%Returns the normalized length dependence factor given the normalized
%contractile element length LCEn

function out=fn(LCEn,W)
%W is the width parameter
out=exp(-((LCEn-1)/W).^2);
