%normalized velocity dependence function
%y is the contraction velocity= -LCEdot

function out=gn(y)  

A = 0.25;			% Hill constant
zmax=1.5;           % Maximum ecc to isometric force ratio

for i=1:length(y)
if y(i)<0									
      out(i)=(A - A*zmax + y(i)*zmax + A*y(i)*zmax)/(A + y(i) + A*y(i) - A*zmax);
      %CE lengthens (Katz model)
   else
      out(i) =	(A - A*y(i))/(A + y(i));		 % CE shortens (Hill model)
end
end
out=out';
  