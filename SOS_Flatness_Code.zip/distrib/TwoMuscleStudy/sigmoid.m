function out = sigmoid(n,aSIGM) 

out = aSIGM(1)./(1+exp(-aSIGM(2)*(n + aSIGM(3))))+aSIGM(4);

end
