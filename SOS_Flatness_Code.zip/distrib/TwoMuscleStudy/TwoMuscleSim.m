%TwoMuscleSim
%Tests flatness parameterization with flat outputs: mass position and
%constant co-contraction, several levels and horizons
%
%
%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%


%This simulation uses normalized muscle dynamics per Zajac 

clear;
clc;
close all;

% define time constant
Lo = 0.01;
vmax = 10*0.01;

tauc = Lo/vmax;

tau_act0 = 0.01;  

tau_act = tau_act0/tauc;    % normalized activation time constant
beta_act = 0.25;            % relationship between activation and deactivation
                            % time constants, tau_act/tau_deact = beta_act



% define muscle parameters
sn = 2;                     % tendon slack length
[aPEE,aPEEPrime] = fitPEnorm; % coefficients defining parallel elastic element
[aSEE,kn,aSEEPrime,aSEEPPrime]=fitSEEnorm(sn); % coefficients defining series elastic element
W = 0.3;    % width parameter for force-length relationship

%Sigmoid function parameters  (for activation dynamics)
aSIGM=[ 9.5751;9.6489; -6.8477;6.2500];


% mass system parameters
m =1;      % normalized mass

% determine initial (equilibrium) conditions
% 
x10=3; %Initial value of y1
Y2range=[0.4:0.4:1.2];
FT10=Y2range(1);
LS10=SEEnorminv(FT10,aSEE,sn);

LC10 = x10-LS10;
LC20 = 1.1;
FT20 = FT10;  %Tendon forces in equilibrium at start
LS20 = SEEnorminv(FT20,aSEE,sn);
C=6.2; %constant length constraint, arbitrary setting
LC20 = C - LS10 - LS20 - LC10;
x20 = 0;
u10 = 0;
u20 = 0;
act10 = (FT10 - PEnorm(LC10,aPEE))/fn(LC10,W)/gn(u10);    % initial activation
act20 = (FT20 - PEnorm(LC20,aPEE))/fn(LC20,W)/gn(u20); 
x0 = [x10;x20;LS10;LS20;u10;u20]; % assemble initial state
    
%Flat output trajectories
%For y1: move from initial x10 to x11
%y1=b*cos(wt)+c, with 
%-b+c=x11
%b+c=x10
%Then c=(x11+x10)/2, b=(x10-x11)/2

x11=1.05*x10;
c=(x11+x10)/2; b=(x10-x11)/2;


nn=2*length(Y2range);
actMatrix=zeros(3,nn);
nMatrix=zeros(3,nn);
ii=0;
for T=[1.25 2 4]
    ii=ii+1;
    jj=0;
    oddcols=[];
    evencols=[];
    for Y2=Y2range
        jj=jj+1;
        w=pi/T;
          
        delta=0.025;
        t=[0:delta:T];
    
    NT=length(t);
    y2=Y2*ones(NT); %try constant co-contraction
    %it must be high enough if slack is to be avoided

    %Derivatives of y1
    %y1=b*cos(w*t)+c;
    %y1dot=-b*w*sin(w*t);
    %y1ddot=-b*w^2*cos(w*t);
    %y2dot=0
    %y1dddot=b*w^3*sin(w*t);


        %Polynomial trajectory with equilibrium at the
        %beginning and end (vel, accel, jerk and rate of jerk must be zero)
        
        AA=[T^7 T^6 T^5 T^4;7*T^6 6*T^5 5*T^4 4*T^3;42*T^5 30*T^4 20*T^3 12*T^2;210*T^4 120*T^3 60*T^2 24*T];BB=[x11-x10;0;0;0];
        coeff=(AA\BB)'; %these are a7 a6 a5 a4
        y1coeff=[coeff 0 0 0 x10];
        y1dotcoeff=polyder(y1coeff);
        y1ddotcoeff=polyder(y1dotcoeff);
        y1dddotcoeff=polyder(y1ddotcoeff);

        y1=polyval(y1coeff,t);
        y1dot=polyval(y1dotcoeff,t);
        y1ddot=polyval(y1ddotcoeff,t);
        y1dddot=polyval(y1dddotcoeff,t);


%LS1, LS2, LC1, LC2, their derivatives and activations
for i=1:NT
    FT1(i)=y2(i)-m*y1ddot(i)/2;
    LS1(i)=SEEnorminv(FT1(i),aSEE,sn);
    LS1dot(i)=-m*y1dddot(i)/SEEnormPrime(LS1(i),sn,aSEEPrime,kn);
    LC1(i)=y1(i)-LS1(i);
    u1(i)=LS1dot(i)-y1dot(i);
    act1(i)=(FT1(i)-PEnorm(LC1(i),aPEE))/fn(LC1(i),W)/gn(u1(i));
  
    
    FT2(i)=y2(i)+m*y1ddot(i)/2;
    LS2(i)=SEEnorminv(FT2(i),aSEE,sn);
    LS2dot(i)=m*y1dddot(i)/SEEnormPrime(LS2(i),sn,aSEEPrime,kn);
    LC2(i)=C-y1(i)-LS1(i);
    u2(i)=LS2dot(i)+y1dot(i);
    act2(i)=(FT2(i)-PEnorm(LC2(i),aPEE))/fn(LC2(i),W)/gn(u2(i));
end


%Solve for neural inputs

%Obtain activation derivatives using diff
a1dot=diff(act1)/delta;
a2dot=diff(act2)/delta;

%Try solutions

for j=1:NT-1
    [n,FVAL,EXITFLAG,OUTPUT]=fsolve(@(n) nleq(n,a1dot(j),act1(j),aSIGM),0);
    n1(j)=n;
    [n,FVAL,EXITFLAG,OUTPUT]=fsolve(@(n) nleq(n,a2dot(j),act2(j),aSIGM),0);
    n2(j)=n;
end
tout=t;

%fill in matrices
actMatrix(ii,2*jj-1)=min(min(act1),min(act2));
actMatrix(ii,2*jj)=max(max(act1),max(act2));

nMatrix(ii,2*jj-1)=min(min(n1),min(n2));
nMatrix(ii,2*jj)=max(max(n1),max(n2));

oddcols=[oddcols 2*jj-1];
evencols=[evencols 2*jj];

    end
end


close all

%Plot paper figure

subplot(2,1,1)
plot(Y2range,actMatrix(1,evencols),'b-*');  %max a, T=1.25
hold on
plot(Y2range,actMatrix(2,evencols),'b-o'); %max a, T=2
plot(Y2range,actMatrix(3,evencols),'b-h'); %max a, T=4

legend('T=1.25','T=2','T=4')

plot(Y2range,actMatrix(1,oddcols),'r-*'); %min a, T=1.25
plot(Y2range,actMatrix(2,oddcols),'r-o'); %min a, T=2
plot(Y2range,actMatrix(3,oddcols),'r-h'); %min a, T=4

plot([Y2range(1) Y2range(end)], [1 1], 'r--')

ylabel('Max and Min $a$', 'Fontsize',14,'Interpreter','Latex')
title('Peak Activations and Neural Inputs vs. Horizon and Co-Contraction','Fontsize',14,'Interpreter','Latex')

subplot(2,1,2)

plot(Y2range,nMatrix(1,evencols),'b-*');  %max n, T=1.25
hold on
plot(Y2range,nMatrix(2,evencols),'b-o'); %max n, T=2
plot(Y2range,nMatrix(3,evencols),'b-h'); %max n, T=4

plot(Y2range,nMatrix(1,oddcols),'r-*'); %min n, T=1.25
plot(Y2range,nMatrix(2,oddcols),'r-o'); %min n, T=2
plot(Y2range,nMatrix(3,oddcols),'r-h'); %min n, T=4


plot([Y2range(1) Y2range(end)], [1 1], 'r--')
plot([Y2range(1) Y2range(end)], [0 0], 'r--')

ylabel('Max and Min $n$', 'Fontsize',14,'Interpreter','Latex')
xlabel('Constant Co-Contraction Level', 'Fontsize',14)



function out=nleq(n,adot,a,aSIGM)
%this must be zero to solve for the neural input given a and adot
    out=adot-sigmoid(n,aSIGM).*(n-a);
end

