%Inverse of tendon force function (outside slack)

function LSEEn=SEEnorminv(FTeqn,aSEE,sn)

%Solve for LSEEn0 according to range of FTeqn

kn=0.5/(1.033-1.02)/sn; %normalized tendon stiffness


if FTeqn<=0,
    error('Undefined equilibrium due to slack')
elseif FTeqn<0.5, %solve through quintic polynomial of toe region
    aSEE(end)=aSEE(end)-FTeqn;
    sols=roots(aSEE');
    %Find root in the range of sn to 1.02*sn
    for i=1:5,
        if isreal(sols(i)) & (sn<=sols(i)<1.02*sn),
            LSEEn=sols(i);
        end
    end
else %solve through linear region
    LSEEn=(FTeqn-0.5)/kn+1.02*sn;
end

    
    
