%Returns derivative of normalized SEE (tendon force)

function out=SEEnormPrime(LSEEn,sn,aSEEPrime,kn)

if LSEEn<sn,
        out=0;
    elseif LSEEn<1.02*sn,
        out=polyval(aSEEPrime,LSEEn);
    else
        out=kn;
    end
end




