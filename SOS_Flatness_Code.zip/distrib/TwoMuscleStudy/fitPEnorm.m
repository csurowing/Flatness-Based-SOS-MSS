%Fits a cubic polynomial to the normalized passive force function

function [a,aPrime]=fitPEnorm

%A matrix

A=[1 1 1 1;3 2 1 0;6 2 0 0;1.5^3 1.5^2 1.5 1];

%b vector

b=[0;0;0;1];

a=inv(A)*b;

aPrime = polyder(a);