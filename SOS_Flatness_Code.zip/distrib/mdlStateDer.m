function xdot=mdlStateDer(t,x,n_time,n,robotpars,musclepars,g,tau_act,beta)

%State derivatives for the 2-link, 6-muscle planar arm

%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%

m1=robotpars.m1;
m2=robotpars.m2;
l1=robotpars.l1;
lc1=robotpars.lc1;
l2=robotpars.l2;
lc2=robotpars.lc2;
I1=robotpars.I1;
I2=robotpars.I2;

d1=musclepars.d1;
d2=musclepars.d2;
a0=musclepars.a0;
Ls=musclepars.Ls;
Lo=musclepars.Lo;
Vm=musclepars.Vm;
W=musclepars.W;
Fmax=musclepars.Fmax;
k=musclepars.k;
aPEE=musclepars.aPEE;


z=x(1:4);
z_1=z(1:2);
z_2=z(3:4);
LS=x(5:10);
a=x(11:end);

%find numerical values for matrices M, C and g
% D(1,1)=m1*lc1^2+m2*(l1^2+lc2^2+2*l1*lc2*cos(z_1(2)))+I1+I2;
% D(1,2)=m2*(lc2^2+l1*lc2*cos(z_1(2)))+I2;
% D(2,1)=D(1,2);
% D(2,2)=m2*lc2^2+I2;

h=-m2*l1*lc2*sin(z_1(2));

C(1,1)=h*z_2(2);
C(1,2)=h*z_2(2)+h*z_2(1);
C(2,1)=-h*z_2(1);
C(2,2)=0;

gg(1,1)=(m1*lc1+m2*l1)*g*cos(z_1(1))+m2*lc2*g*cos(z_1(1)+z_1(2));
gg(2,1)=m2*lc2*g*cos(z_1(1)+z_1(2));

%Symbolic M inverse
Dinv=[(m2*lc2^2 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2),                            -(m2*lc2^2 + l1*m2*cos(z_1(2))*lc2 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2);
-(m2*lc2^2 + l1*m2*cos(z_1(2))*lc2 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2), (m2*l1^2 + 2*m2*cos(z_1(2))*l1*lc2 + m1*lc1^2 + m2*lc2^2 + I1 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2)];

%Compute the linkage acceleration
Phi=SEE(LS,Ls,k); %meant for a vector 
ArmMatrix=[d1';d2'];
tau=ArmMatrix*Phi;

z2dot=Dinv*(-C*z_2-gg+tau);

%Compute Lc
LC=a0-d1*z_1(1)-d2*z_1(2)-LS;

%Compute parallel force
FP=PE(LC,aPEE,Lo);

%Compute z
z=(Phi-FP)./(f1(LC,W,Lo,Fmax).*a.*Fmax);

%Compute u
u=ginv(z,Vm);

%Compute Lsdot
Lsdot=-d1*z_2(1)-d2*z_2(2)+u; %recall u=-Lcdot

%Interpolate to find proper n inputs and find adot

%Compute adot
for i=1:6
n_input=interp1(n_time,n(:,i),t);    
adot(i)=actdynsat(n_input,a(i),tau_act,beta);

end

%Assemble return derivatives
xdot=[z_2;z2dot;Lsdot;adot'];
