%testFlatnessRH
%Tests flatness-based receding-horizon solutions in a closed-loop simulation

%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%
%Requires the Matlab Optimization Toolbox (for linprog)


clear;clc;close all

% define time constant
tau_act = 0.01;  
beta_act = 0.25;
tau_deact = tau_act/beta_act;


load aSEEandaPEE                           
                            
%Linkage constants

robotpars.m1=2.24;
robotpars.m2=1.76;
robotpars.l1=0.33;
robotpars.lc1=0.1439;  %to center of mass
robotpars.l2=0.32;
robotpars.lc2=0.2182;  %to center of mass
robotpars.I1=0.0253;
robotpars.I2=0.0395;


%Kinematic info on muscle attachment
d1=[0.05;-0.05;0.03;-0.03;0;0];
d2=[0;0;0.03;-0.03;-0.03;0.03];
a0=[0.1840;0.1055;0.4283;0.1916;0.2387;0.1681];
%Muscle slack parameters
Ls=[0.0538;0.0538;0.2298;0.1905;0.1905;0.0175];

%Optimal lengths
Lo = [0.1280 0.1280 0.1422 0.0877 0.0877 0.1028]';

Vm = 10*Lo;
W  = 0.56*ones(6,1);

%Max muscle forces
Fmax=[800;800;1000;1000;700;700];

%k vector
k=Fmax./(0.04*Ls).^2;

musclepars.d1=d1;
musclepars.d2=d2;
musclepars.a0=a0;
musclepars.Ls=Ls;
musclepars.Lo=Lo;
musclepars.Vm=Vm;
musclepars.W=W;
musclepars.Fmax=Fmax;
musclepars.k=k;
musclepars.aPEE=aPEE;


%Setup initial conditions
q0=[20;20]*pi/180;qdot0=[0;0];

%Choose motion target
qf=[80;80]*pi/180;

%Choose prediction horizon and discretization interval
N=11;  
T=0.5;
delta=T/(N-1);

%Choose simulation horizon 
Tsim=1.5;
MPCiter=ceil(Tsim/delta);

g=1*9.81; %Select gravity constant

%Solve steady-state optimizer at the specified q0 and force reserves
 
FTreserve=20*[1;1;1;1;1;0.5];

[a,LS,Phi]=FlatSSInit(q0,robotpars,musclepars,g,FTreserve);

 
LS0=LS;
act0=a;
z0=[q0;0;0];
x0=[z0;LS0;act0];


% Set options
atol_ode  = 1e-6;%1e-12;
rtol_ode  = 1e-6;%1e-12;
options = odeset('AbsTol', atol_ode, 'RelTol', rtol_ode);

%Without these options, the integration may diverge

%Enter MPC simulation loop
%Initialize closed-loop variables for storage
x=x0;
xcl=x0;
tsim=0;
tcl=0;
ncl=[];


for ii=1:MPCiter 
    %tic
    [t,npred,act,LS,u,Phi,q1pred,q2pred]=MDLflatnessMPClinprog(x,qf,FTreserve,robotpars,musclepars,g,T,delta,tau_act,beta_act); 
    %tmpc=toc;
    %Extract MPC feedback
    n=npred(1,:)';
   
    %Extract activations
    a=act(:,1);
    
    %plot predictions 
    figure(1)
    subplot(2,1,1);plot(tsim+t,q1pred,'k');
    hold on;
    subplot(2,1,2);plot(tsim+t,q2pred,'k');
    hold on;
    
    %plot neural inputs
    figure(2)
subplot(3,2,1)
plot(tsim,n(1),'r*');hold on
ylabel('$n_{1}$','Fontsize',14, 'Interpreter','Latex')
title('Neural Control Inputs: Receding Horizon Closed-Loop Simulation','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,2);hold on
plot(tsim,n(2),'r*')
ylabel('$n_{2}$','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,3);hold on
plot(tsim,n(3),'r*')
ylabel('$n_{3}$','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,4);hold on
plot(tsim,n(4),'r*')
ylabel('$n_{4}$','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,5);hold on
plot(tsim,n(5),'r*');
ylabel('$n_{5}$','Fontsize',14, 'Interpreter','Latex')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
subplot(3,2,6);hold on
plot(tsim,n(6),'r*')
ylabel('$n_{6}$','Fontsize',14, 'Interpreter','Latex')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')

    
    %Update plant dynamics
   %tic
    [TOUT,YOUT]=ode23(@(t,x) mdlStateDer4MPC(t,x,n,robotpars,musclepars,g,tau_act,beta_act),[0  delta],x,options); 
   %tupdate=toc;
    
    x=YOUT(end,:)';
    tsim=tsim+delta;
    %store closed-loop plant state and time
    tcl=[tcl;tsim];
    xcl=[xcl x];
    %store closed-loop neural control
    ncl=[ncl n];

    a=x(11:end);
    
    %Report time
    %tmpc+tupdate
    
    %plot closed-loop states
    figure(1)
    subplot(2,1,1);
    plot(tsim,x(1),'r*');
    subplot(2,1,2);
    plot(tsim,x(2),'r*');
    
    %Plot activations
figure(3)
subplot(3,2,1)
plot(tsim,a(1),'r*');hold on
ylabel('$a_{1}$','Fontsize',14, 'Interpreter','Latex')
title('Activations: Receding Horizon Closed-Loop Simulation','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,2);hold on
plot(tsim,a(2),'r*')
ylabel('$a_{2}$','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,3);hold on
plot(tsim,a(3),'r*')
ylabel('$a_{3}$','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,4);hold on
plot(tsim,a(4),'r*')
ylabel('$a_{4}$','Fontsize',14, 'Interpreter','Latex')
subplot(3,2,5);hold on
plot(tsim,a(5),'r*');
ylabel('$a_{5}$','Fontsize',14, 'Interpreter','Latex')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
subplot(3,2,6);hold on
plot(tsim,a(6),'r*')
ylabel('$a_{6}$','Fontsize',14, 'Interpreter','Latex')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
end

%Refine figures for paper
figure(1)
subplot(2,1,1)
title('Joint Angles: Receding Horizon Closed-Loop Simulation','Fontsize',14, 'Interpreter','Latex')
legend('Predictions','Closed-Loop')
ylabel('$q_1, q_{1pred}$','Fontsize',14, 'Interpreter','Latex')
axis([0 1.5 0 2])

subplot(2,1,2)
ylabel('$q_2, q_{2pred}$','Fontsize',14, 'Interpreter','Latex')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
axis([0 1.5 0 2])

figure(2)
subplot(3,2,1)
plot(tcl(1:end-1),ncl(1,:),'r')
subplot(3,2,2)
plot(tcl(1:end-1),ncl(2,:),'r')
subplot(3,2,3)
plot(tcl(1:end-1),ncl(3,:),'r')
subplot(3,2,4)
plot(tcl(1:end-1),ncl(4,:),'r')
subplot(3,2,5)
plot(tcl(1:end-1),ncl(5,:),'r')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
subplot(3,2,6)
plot(tcl(1:end-1),ncl(6,:),'r')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')

figure(3)
subplot(3,2,1)
plot(tcl,xcl(11,:),'r')
subplot(3,2,2)
plot(tcl,xcl(12,:),'r')
subplot(3,2,3)
plot(tcl,xcl(13,:),'r')
subplot(3,2,4)
plot(tcl,xcl(14,:),'r')
subplot(3,2,5)
plot(tcl,xcl(15,:),'r')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
subplot(3,2,6)
plot(tcl,xcl(16,:),'r')
xlabel('Time, s', 'Fontsize',14, 'Interpreter','Latex')
