%calcTauBounds2link
%Finds torque bounds for a two-link planar robot for point-to-point motion
%with polynomial trajectory
%Enumeration solution
%
%interval=[0 T] is the time interval where the bounds are to be found
%(time invariance of robot+actuator dynamics assumed)
%robotpars is a structure with the physical parameters
%
% Create structure as follows
%
% robotpars.m1=1;
% robotpars.m2=0.5;
% robotpars.l1=0.6;
% robotpars.lc1=0.3;  %to center of mass
% robotpars.l2=0.4;
% robotpars.lc2=0.2;  %to center of mass
% robotpars.I1=0.5;
% robotpars.I2=0.25;

%q0 and q1 are the joint positions at t=0 and t=T respectively
%qdot0 is the joint velocity at t=0

function [tau1,tau2,taumax1,taumin1,taumax2,taumin2,taumax12,taumin12]=calcTauBounds2linkEnum(T,robotpars,coeff1,coeff2,delta,g,draw)

%Maximization is across time, independently for each joint torque or torque
%difference

x=[0:delta:T];

for i=1:length(x)
    tau(:,i)=robottorque(x(i),coeff1,coeff2,robotpars,g);
end


%Show solutions graphically

tau1=tau(1,:);
tau2=tau(2,:);
tau12=tau(1,:)-tau(2,:);

taumax1=max(tau1);
taumin1=min(tau1);

taumax2=max(tau2);
taumin2=min(tau2);

taumin12=min(tau12);
taumax12=max(tau12);


q1=polyval(coeff1,x);
q2=polyval(coeff2,x);

if draw
    subplot(2,2,1)
    plot(x,q1);
    ylabel('q_1')
    subplot(2,2,2)
    plot(x,q2);
    ylabel('q_2')
    subplot(2,2,3)
    plot(x,tau1)
    ylabel('\tau_1')
    subplot(2,2,4)
    plot(x,tau2)
    ylabel('\tau_2')
%     figure
%     plot(x,tau12)
%     ylabel('\tau_1-\tau_2')
end

end

function tau=robottorque(t,q1coeff,q2coeff,robotpars,g)

%t is a time between 0 and T

q1dotcoeff=polyder(q1coeff);
q2dotcoeff=polyder(q2coeff);


q1ddotcoeff=polyder(q1dotcoeff);
q2ddotcoeff=polyder(q2dotcoeff);

q1val=polyval(q1coeff,t);
q2val=polyval(q2coeff,t);

q1dotval=polyval(q1dotcoeff,t);
q2dotval=polyval(q2dotcoeff,t);

q1ddotval=polyval(q1ddotcoeff,t);
q2ddotval=polyval(q2ddotcoeff,t);


m1=robotpars.m1;
m2=robotpars.m2;
l1=robotpars.l1;
lc1=robotpars.lc1;
l2=robotpars.l2;
lc2=robotpars.lc2;
I1=robotpars.I1;
I2=robotpars.I2;



z=[q1val;q2val;q1dotval;q2dotval];

n=length(z);
z_1=z(1:n/2);
z_2=z(n/2+1:n);

%find numerical values for matrices M, C and g
D(1,1)=m1*lc1^2+m2*(l1^2+lc2^2+2*l1*lc2*cos(z_1(2)))+I1+I2;
D(1,2)=m2*(lc2^2+l1*lc2*cos(z_1(2)))+I2;
D(2,1)=D(1,2);
D(2,2)=m2*lc2^2+I2;

h=-m2*l1*lc2*sin(z_1(2));

C(1,1)=h*z_2(2);
C(1,2)=h*z_2(2)+h*z_2(1);
C(2,1)=-h*z_2(1);
C(2,2)=0;

gg(1,1)=(m1*lc1+m2*l1)*g*cos(z_1(1))+m2*lc2*g*cos(z_1(1)+z_1(2));
gg(2,1)=m2*lc2*g*cos(z_1(1)+z_1(2));

%Calculate the torque

tau=D*[q1ddotval;q2ddotval]+C*z_2+gg;

end

