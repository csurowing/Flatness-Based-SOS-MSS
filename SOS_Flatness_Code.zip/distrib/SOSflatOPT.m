
function [t,n,act,LS,u,Phi,q1,q2]=SOSflatOpt(x,qff,FTreserve,robotpars,musclepars,g,T,delta,tau_act,beta_act)

%Flatness-based SOS open-loop optimization 
%Matches given initial conditions (must be feasible) and imposes terminal
%equilibrium

%Simulation code for paper "Motion Optimization for Musculoskeletal
%Dynamics: A Flatness-Based Sum-of-Squares Approach"
%by Hanz Richter and Holly Warner
%
%Cleveland State University, Center for Human-Machine Systems, 2019
%


%Parse parameters

m1=robotpars.m1;
m2=robotpars.m2;
l1=robotpars.l1;
lc1=robotpars.lc1;
l2=robotpars.l2;
lc2=robotpars.lc2;
I1=robotpars.I1;
I2=robotpars.I2;

d1=musclepars.d1;
d2=musclepars.d2;
a0=musclepars.a0;
Ls=musclepars.Ls;
Lo=musclepars.Lo;
Vm=musclepars.Vm;
W=musclepars.W;
Fmax=musclepars.Fmax;
k=musclepars.k;
aPEE=musclepars.aPEE;


%Parse inputs
z=x(1:4);
z_1=z(1:2);
z_2=z(3:4);
LS=x(5:10);
a=x(11:end);

q0=z_1;
qdot0=z_2;

ArmMatrix=[d1';d2'];

D=[ArmMatrix;0.5 0.5 0 0 0 0;0 0 0.5 0.5 0 0;0 0 0 0 0.5 0.5;1 0 0 0 0 0];

%Calculate required initial LSdot

Phi=SEE(LS,Ls,k);
%Compute Lc
LC=a0-d1*q0(1)-d2*q0(2)-LS;
%Compute parallel force
FP=PE(LC,aPEE,Lo);
%Compute z
z=(Phi-FP)./(f1(LC,W,Lo,Fmax).*a.*Fmax);
%Compute u
u=ginv(z,Vm);
%Compute Lsdot
Lsdot=-d1*qdot0(1)-d2*qdot0(2)+u; %recall u=-Lcdot

%Compute torque and co-contraction required at start
TYReq=D*Phi;
tau0Req=TYReq(1:2);

%Compute rates of torque and co-contraction required at start
TYdotReq=D*(SEEPrime(LS,Ls,k).*Lsdot);

%Solve for jerk and acceleration meeting constraints
qddot0=robotaccel(q0,qdot0,tau0Req,robotpars,g);
% 
AccelMatrix=[-4*l1*lc2*m2*qdot0(2)*sin(q0(2)) -l1*lc2*m2*sin(q0(2))*(qdot0(1)+2*qdot0(2));
 l1*lc2*m2*sin(q0(2))*(2*qdot0(1)-qdot0(2)) 0];
  
JerkMatrixInv=[(2*(m2*lc2^2 + I2))/(2*I1*I2 + l1^2*lc2^2*m2^2 + 2*I2*l1^2*m2 + 2*I2*lc1^2*m1 + 2*I1*lc2^2*m2 + 2*lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(1)*sin(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(2)*sin(2*q0(2)) + 2*l1*lc2^3*m2^2*qdot0(1)*sin(q0(2)) + 2*l1*lc2^3*m2^2*qdot0(2)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(1)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(2)*sin(q0(2))), -(2*(I2 + lc2^2*m2 + l1*lc2*m2*cos(q0(2)) - l1*lc2*m2*qdot0(1)*sin(q0(2)) - l1*lc2*m2*qdot0(2)*sin(q0(2))))/(2*I1*I2 + l1^2*lc2^2*m2^2 + 2*I2*l1^2*m2 + 2*I2*lc1^2*m1 + 2*I1*lc2^2*m2 + 2*lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(1)*sin(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(2)*sin(2*q0(2)) + 2*l1*lc2^3*m2^2*qdot0(1)*sin(q0(2)) + 2*l1*lc2^3*m2^2*qdot0(2)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(1)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(2)*sin(q0(2)));
     -(2*(m2*lc2^2 + l1*m2*cos(q0(2))*lc2 + I2))/(2*I1*I2 + l1^2*lc2^2*m2^2 + 2*I2*l1^2*m2 + 2*I2*lc1^2*m1 + 2*I1*lc2^2*m2 + 2*lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(1)*sin(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(2)*sin(2*q0(2)) + 2*l1*lc2^3*m2^2*qdot0(1)*sin(q0(2)) + 2*l1*lc2^3*m2^2*qdot0(2)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(1)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(2)*sin(q0(2))),                          (2*(m2*l1^2 + 2*m2*cos(q0(2))*l1*lc2 + m1*lc1^2 + m2*lc2^2 + I1 + I2))/(2*I1*I2 + l1^2*lc2^2*m2^2 + 2*I2*l1^2*m2 + 2*I2*lc1^2*m1 + 2*I1*lc2^2*m2 + 2*lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(1)*sin(2*q0(2)) + l1^2*lc2^2*m2^2*qdot0(2)*sin(2*q0(2)) + 2*l1*lc2^3*m2^2*qdot0(1)*sin(q0(2)) + 2*l1*lc2^3*m2^2*qdot0(2)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(1)*sin(q0(2)) + 2*I2*l1*lc2*m2*qdot0(2)*sin(q0(2)))];
 
qdddot0=JerkMatrixInv*(TYdotReq(1:2)-AccelMatrix*qddot0);    

%Solution by polynomial matching:
%Initial position, velocity, acceleration and jerk 
%True equilibrium: final value, zero velocity, acceleration, jerk and rate
%of jerk.
%The above needs an 8th-order polynomial

coeff1=poly8(q0(1),qdot0(1),qddot0(1),qdddot0(1),qff(1),T);
coeff2=poly8(q0(2),qdot0(2),qddot0(2),qdddot0(2),qff(2),T);

Y36dot0=TYdotReq(3:end);    

%Find the torque bounds for the above trajectories
tic    
[tau1,tau2,taumax1,taumin1,taumax2,taumin2,taumax12,taumin12]=calcTauBounds2linkEnum(T,robotpars,coeff1,coeff2,delta,g,1);
toc


%Initial Y36 constraint
Y360=D*Phi;
Y360=Y360(3:end);

%Distribution matrix inverse
Di=inv(D);

Dy=Di(:,3:6);
Df=Di(:,1:2);

%SOS solution

%Solve polynomial optimization for y3,y4,y5 and y6
syms t
Program1=sosprogram(t);
vec2=monomials(t,[0 1 2 3 4]);
[Program1,v2] = sospolymatrixvar(Program1,vec2,[4 1]);

area=sum(int(v2,[0 T]));

Program1=sossetobj(Program1,area);
    
%Initial co-contraction constraint 
Program1=soseq(Program1,subs(v2,t,0)-Y360); 

%Set up terminal equality constraints for y3,y4,y5,y6
v2dot=diff(v2);
Program1=soseq(Program1,subs(v2dot,t,T));

v2ddot=diff(v2dot);
Program1=soseq(Program1,subs(v2ddot,t,T));

%Initial rate of co-contraction constraint
Program1=soseq(Program1,subs(v2dot,t,0)-Y36dot0);%ensures continuity of a predictions

%Set up inequality constraints for y3,y4,y5,y6

leftside=Dy*v2;
rightside=FTreserve-Df(:,1).*[0;0;taumin1;taumax1;taumin12;taumax12];

Program1=sosineq(Program1,leftside-rightside,[0 T]);

Program1=sossolve(Program1);

vsol2 = sosgetsol(Program1,v2);

t=[0:delta:T];

y3=eval(vsol2(1));
y4=eval(vsol2(2));
y5=eval(vsol2(3));
y6=eval(vsol2(4));


%Evaluate motion and derivatives
q1=polyval(coeff1,t);
q2=polyval(coeff2,t);
coeffd1=polyder(coeff1);
coeffd2=polyder(coeff2);
q1dot=polyval(coeffd1,t);
q2dot=polyval(coeffd2,t);

%Calculate f1dot and f2dot by numerical differentiation
%(repeat last entry to maintain length

f1dot=diff([tau1 tau1(end)])/delta;
f2dot=diff([tau2 tau2(end)])/delta;

NT=length(t);

ydot=eval(diff(vsol2))';
yddot=eval(diff(diff(vsol2)))'; %to verify attainment of the zero derivative conditions

%Calculate muscle state trajectories

for i=1:NT
    
    %find tendon forces
    Phi(:,i)=Di*[tau1(i);tau2(i);y3(i);y4(i);y5(i);y6(i)];
    
    %find series element lengths
    LS(:,i)=SEEinv(Phi(:,i),Ls,k);
  
    %find LS rates 
    denom=SEEPrime(LS(:,i),Ls,k);
    num=Di*[f1dot(i);f2dot(i);ydot(i,:)'];
    LSdot(:,i)=num./denom;
    
    %find LC, u and a
    L(:,i)=a0-d1*q1(i)-d2*q2(i);
    Ldot(:,i)=-d1*q1dot(i)-d2*q2dot(i);
    LC(:,i)=L(:,i)-LS(:,i);
    u(:,i)=LSdot(:,i)-Ldot(:,i);
    FP(:,i)=PE(LC(:,i),aPEE,Lo);
    act(:,i)=(Phi(:,i)-FP(:,i))./(f1(LC(:,i),W,Lo,Fmax).*g1(u(:,i),Vm).*Fmax);
end

%Obtain activation derivatives using diff
%(repeat last entry to maintain length)


act=[act act(:,end)];

a1dot=diff(act(1,:))/delta;
a2dot=diff(act(2,:))/delta;

a3dot=diff(act(3,:))/delta;
a4dot=diff(act(4,:))/delta;

a5dot=diff(act(5,:))/delta;
a6dot=diff(act(6,:))/delta;


%Solve for neural inputs (based on saturation-type activation function)

for j=1:NT
    [n,solfound]=solvesat(tau_act,beta_act,act(1,j),a1dot(j));
    n1(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(2,j),a2dot(j));
    n2(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(3,j),a3dot(j));
    n3(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(4,j),a4dot(j));
    n4(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(5,j),a5dot(j));
    n5(j)=n;
    [n,solfound]=solvesat(tau_act,beta_act,act(6,j),a6dot(j));
    n6(j)=n;
end


%Return optimal n sequence and state predictions

t=t';
n=[n1' n2' n3' n4' n5' n6'];


end



function qddot=robotaccel(q,qdot,tau,robotpars,g)

%Returns instantaneous robot acceleration

m1=robotpars.m1;
m2=robotpars.m2;
l1=robotpars.l1;
lc1=robotpars.lc1;
l2=robotpars.l2;
lc2=robotpars.lc2;
I1=robotpars.I1;
I2=robotpars.I2;


%Port to old code
z=[q;qdot];

n=length(z);
z_1=z(1:n/2);
z_2=z(n/2+1:n);

%Symbolic M inverse
Dinv=[(m2*lc2^2 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2),                            -(m2*lc2^2 + l1*m2*cos(z_1(2))*lc2 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2);
-(m2*lc2^2 + l1*m2*cos(z_1(2))*lc2 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2), (m2*l1^2 + 2*m2*cos(z_1(2))*l1*lc2 + m1*lc1^2 + m2*lc2^2 + I1 + I2)/(I1*I2 + l1^2*lc2^2*m2^2 + I2*l1^2*m2 + I2*lc1^2*m1 + I1*lc2^2*m2 + lc1^2*lc2^2*m1*m2 - l1^2*lc2^2*m2^2*cos(z_1(2))^2)];


h=-m2*l1*lc2*sin(z_1(2));

C(1,1)=h*z_2(2);
C(1,2)=h*z_2(2)+h*z_2(1);
C(2,1)=-h*z_2(1);
C(2,2)=0;

gg(1,1)=(m1*lc1+m2*l1)*g*cos(z_1(1))+m2*lc2*g*cos(z_1(1)+z_1(2));
gg(2,1)=m2*lc2*g*cos(z_1(1)+z_1(2));

%Calculate the acceleration

qddot=Dinv*(-C*z_2-gg+tau);

end



function coeff=poly8(q0,qd0,qdd0,qddd0,qf,T)

c0=q0;
c1=qd0;
c2=qdd0/2;
c3=qddd0/6;

c48=[     -(5*(qddd0*T^3 + 9*qdd0*T^2 + 42*qd0*T + 84*q0 - 84*qf))/(6*T^4);
      (5*qddd0*T^3 + 60*qdd0*T^2 + 315*qd0*T + 672*q0 - 672*qf)/(3*T^5);
 -(10*qddd0*T^3 + 135*qdd0*T^2 + 756*qd0*T + 1680*q0 - 1680*qf)/(6*T^6);
      (5*qddd0*T^3 + 72*qdd0*T^2 + 420*qd0*T + 960*q0 - 960*qf)/(6*T^7);
        -(qddd0*T^3 + 15*qdd0*T^2 + 90*qd0*T + 210*q0 - 210*qf)/(6*T^8)  ];
   
   coeff=[flipud(c48);c3;c2;c1;c0];

end



