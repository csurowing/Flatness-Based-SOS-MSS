%PE.m

%Returns the passive muscle force (PE) for a vector of muscle lenghts


function out=PE(LC,aPEE,Lo)


for i = 1:length(LC)
    
if LC(i)<Lo(i),
        out(i)=0;
    else
        out(i)=polyval(aPEE(:,i),LC(i));
end

end

out=out';

out = zeros(length(LC),1);
