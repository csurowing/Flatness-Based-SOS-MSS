%Velocity dependence function
%u is the contraction velocity= -LCdot

function out=g1(u,Vm)  

A = 0.25;			% Hill constant
gmax = 1.5;         % Maximum ecc to isometric force ratio

for idx = 1:length(u)


if u(idx) < 0
      out(idx)=(A*Vm(idx) - A*Vm(idx)*gmax + u(idx)*gmax + A*u(idx)*gmax)./(A*Vm(idx) + u(idx) + A*u(idx) - A*Vm(idx)*gmax);     %CE lengthens (Katz model)
else 
      out(idx) =	(A*Vm(idx) - A*u(idx))./(A*Vm(idx) + u(idx));       % CE shortens (Hill model)
end
end

out = out';


    