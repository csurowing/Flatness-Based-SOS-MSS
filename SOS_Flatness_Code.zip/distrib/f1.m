%Returns the length dependence factor given the
%contractile element length LC

function out=f1(LC,W,Lo,Fm)
%W is the width parameter
out = exp(-((LC-Lo)./(W.*Lo)).^2);
