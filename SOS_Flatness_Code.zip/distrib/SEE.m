%Returns tendon force (quadratic model)

function out=SEE(LSEE,s,k)

out=k.*(LSEE-s).^2;



